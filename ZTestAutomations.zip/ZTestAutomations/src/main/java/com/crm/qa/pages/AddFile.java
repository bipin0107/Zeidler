package com.crm.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.qa.base.TestBase;

public class AddFile extends TestBase{
	
	
	@FindBy(xpath = "//a[contains(text(),'Add Images')]")
	WebElement addimages;
	
	@FindBy(xpath = "//form[@id='file_manager_dropzone']")
	WebElement dropdragimages;
	
	@FindBy(xpath = "//body[@class='bigtree browser_chrome browser_chrome_78']")
	WebElement deleteimages;
	
	

	// Initializing the Page Objects:
	public AddFile() {
		PageFactory.initElements(driver, this);
	}
	
	
	public void UploadImages()
	{
		
		dropdragimages.sendKeys("C:\\newhtml.html");

	}
	
	public void DeleteImages()
	{
		
		deleteimages.click();

	}
	
	
	
	public void clickOnNewContactLink(){
		Actions action = new Actions(driver);
		action.moveToElement(addimages).build().perform();
		
		
	}
	

}
